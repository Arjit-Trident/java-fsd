package PracticePro4;

import java.util.Scanner;

class Division{
	void display(double value1,double value2) {
		try {
			System.out.println("Division value is "+value1/value2);
		}
		catch(Exception e){
			e.getStackTrace(); 
		}
		finally {
			System.out.println("Thank You!");
		}
	}
}
public class ExceptionExmpl {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two values :");
		double value1 = sc.nextDouble(); //take input 5
		double value2 = sc.nextDouble(); //take input 0
		Division dv = new Division();
		dv.display(value1,value2);
	}
}

