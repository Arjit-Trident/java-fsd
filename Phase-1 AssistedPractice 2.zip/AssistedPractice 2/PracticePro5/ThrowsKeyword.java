package PracticePro5;

public class ThrowsKeyword {
	static void calculate() throws Exception{
		int a=20,b=0,result;
		result = a/b;
		System.out.println("Result is "+result);
	}
	public static void main(String[] args) {
		try {
			calculate();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}