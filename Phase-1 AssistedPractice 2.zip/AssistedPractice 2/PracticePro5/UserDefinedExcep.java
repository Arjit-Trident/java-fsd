package PracticePro5;

class UserException extends Exception{

	@Override
	public String toString() {
		return "You are not 18+, You can't vote.";
	}
	public void ageValidation(int age) throws UserException {
		if(age>=18) {
			System.out.println("right to vote ");
		}
		else {
			throw new UserException();
		}
	}
}
public class UserDefinedExcep {

	public static void main(String[] args) throws UserException {
		UserException ex = new UserException();
		ex.ageValidation(20);
	}

}

