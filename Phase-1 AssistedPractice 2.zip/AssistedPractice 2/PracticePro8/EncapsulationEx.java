package PracticePro8;

public class EncapsulationEx {
	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Encaps en = new Encaps();
			en.setEid(1);
			en.setEname("Arjit");
			en.setEmail("ap@gmail");
			
			Encaps en1 = new Encaps();
			en1.setEid(2);
			en1.setEname("pradhan");
			en1.setEmail("gdf@gs");
			
			System.out.println(en);
			System.out.println(en1);
		

	}

}
