package PracticePro8;

class Car{
	int val=10;
	void display() {
		System.out.println("This Bike Base class");
	}
}
class Audi extends Car{
	void show() {
		System.out.println("This is Audi Child class");
		val++;
		System.out.println("Accesssing Parent class in child class and the value is "+val);
		super.display();
	}
}

public class InheritanceEx {
	public static void main(String[] args) {
		Audi ad = new Audi();
		ad.show();

	}

}
