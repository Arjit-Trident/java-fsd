package Arithmatic_Calculator;

public class ArithmaticCalc {
int num1,num2;
	
	void add(int num1,int num2) {
		System.out.println("Addition is: "+(num1+num2)+"\n");
	}
	
	void sub(int num1,int num2) {
		System.out.println("Substraction is: "+(num1-num2)+"\n");
	}
	
	void multi(int num1,int num2) {
		System.out.println("Multiplication is: "+(num1*num2)+"\n");
	}
	
	void div(int num1,int num2) {
		System.out.println("Division is: "+(num1/num2)+"\n");
	}
	
	void mod(int num1,int num2) {
		System.out.println("Modulus is: "+(num1%num2)+"\n");
	}
	
	

}
