package PracticeProject3;

public class MethodExe2 {
	public void sum(int a, int b)
	{
		System.out.println("Sum of two no is "+(a+b));
		
	}
public void sum(double x, double y)
{
	System.out.println("Sum of two no is "+(x+y));
}
public static void main(String args[])
{
	MethodExe2 obj=new MethodExe2();
	obj.sum(10,15);
	obj.sum(20.4,30.3);
	
}

}
