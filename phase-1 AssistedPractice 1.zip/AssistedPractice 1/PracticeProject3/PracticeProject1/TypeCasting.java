package PracticeProject1;

public class TypeCasting {
	public static void main(String[] args)
	{
		char ch='D';
		System.out.println("implicit Type casting");
		System.out.println("value of ch "+ch);
		
		int i=ch;
		System.out.println("value of i ="+i);
		float f=ch;
		System.out.println("value of f ="+f);
		long l=ch;
		System.out.println("value of l ="+l);
		double d=ch;
		System.out.println("value of d ="+d);
		
		System.out.println("explicit Type casting");
		double val=55.2;
		int a=(int)val;
		System.out.println("value of val="+val);
		System.out.println("value of a="+a);
		
		float b=(float)val;
		System.out.println("value of b="+b);
		
		
	}

}
