package PracticeProject3;

public class VolumeOfBox {
	double display(double length,double breadth,double height) {
		return length*breadth*height;
	}

}
