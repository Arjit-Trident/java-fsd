package PracticeProject4;

public class DefConstructor {
	DefConstructor()
	{
		int a=100;
		int b=200;
		int sum=a+b;
		System.out.println("Value of Sum is "+sum);
	}
	public static void main(String args[])
	{
		DefConstructor obj = new DefConstructor();
	}
}
