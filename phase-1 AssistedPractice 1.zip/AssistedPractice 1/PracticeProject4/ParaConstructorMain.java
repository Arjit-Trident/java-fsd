package PracticeProject4;

public class ParaConstructorMain {
	public static void main(String args[])
	{
	ParaConstructor p = new ParaConstructor(100,200);
	}

}
